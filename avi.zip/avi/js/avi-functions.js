$(document).ready(function(){

//definindo nas variaveis todos os campos de interação do DOM
var alertMsg      = '<strong>Atenção:</strong> Você está em uma sessão _;).';
var msgDefault    = 'Olá, <strong>Robson</strong>! Sou o assistente virtual do Itaú e estou aqui para esclarecer as suas dúvidas de cartão de crédito. Como posso te ajudar?';
var main          = $('#main');
var btnSendChat   = $('#tela-conversa input[type=submit]');
var btnSendValid  = $('#tela-validacao input[type=submit]');
var fieldTextChat = $('#tela-conversa textarea[name=msg]');

//funções defaul 
//pegar o tempo real
function getRealTime(){
	var data = new Date();
	monName = new Array ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12');
	data = data.getDate () + '/' + monName[data.getMonth()] +  '/'  +     data.getFullYear () + ' ' + data.getHours() + ':' + data.getMinutes();	
	return data;
}


//human balão
function humanTalk(msgVar){
	var human  = '<div class="wrap-response human">';
		human += 	'<div class="icon-human"></div>';
		human +=		'<div class="bal-send">';
		human +=		'<div class="bal-tri"></div>';
		human +=			'<p>'+ msgVar.val() +'</p>';
		human +=		'</div>';
		human +=     	'<div class="date-time">';
		human +=		 	'<p>Eu - '+ getRealTime() +'</p>';
		human +=     	'</div>';
		human += '</div>';
		return human;
}

//bot balão
function botTalk(msgVar){
	var bot  = '<div class="wrap-response bot">';
		bot +=		'<div class="bal-response">';
		bot +=		'<div class="bal-tri"></div>';
		bot +=			'<p>'+ msgVar +'</p>';
		bot +=		'</div>';
		bot += 	'<div class="icon-avi"></div>';
		bot +=     	'<div class="date-time">';
		bot +=		 	'<p>Assistente Virtual Itaú - '+ getRealTime() +'</p>';
		bot +=     	'</div>';
		bot += '</div>';
		return bot;
}

//limpa campo field
function cleanField(fieldVar){
	fieldVar.val('');
	fieldVar = fieldVar.val().replace('\n', '');
}

//envia mensagem 
function sendMsgChat(){
	var msg = fieldTextChat;
	if($.trim(msg.val()) !== ''){
	//adiciona a mensagem à tela do chat
		main.append(humanTalk(msg));

//teste envio ajax jquery 
 jQuery.post('data.php',{nome: 'Robson', mensagem: msg.val()},function(data){
 //mostrando o retorno do post
 main.append(botTalk(data));
 });

		main.animate({ scrollTop: main.prop('scrollHeight')}, 1000);
 		cleanField(msg);
		//scroll bottom 
	}
}

//removendo breakLine do text area
function removeBreakLine(fieldText){
	var removeBL = fieldText.val().replace('\n', '');
	fieldText.val(removeBL);
}

//temporariamente primeira tela off
	$('#tela-validacao').css('display', 'none');

//validate function.
function validateFields(fieldVar){

}

//verificação inicial, se nada estiver no wrap, apresentar tela de boas vindas! 
if($('#main').val() == ''){
	main.append(botTalk(msgDefault));
}

//inicio simulação funcionamento tela mocada... 
btnSendValid.click(function(e){
	//removendo função form 
	e.preventDefault();
	//vars
	var userId    = $('input[name=user-id]');
	var sessionId = $('input[name=session-id]');
	var agencia   = $('input[name=agencia]');
	var segmento  = $('input[name=segmento]');
	var canal     = $('input[name=canal]');

//$('#tela-validacao').slideUp('slow').fadeOut('slow');
//$('#tela-conversa').fadeIn('slow');

});// fim tela simulação 

//tela conversa
fieldTextChat.keypress(function(e){
	//removendo breakLine
	removeBreakLine($(this));
	//send ao dar enter.
	if(e.keyCode == 13){
		sendMsgChat();
	}
});

btnSendChat.click(function(e){
	removeBreakLine(fieldTextChat);
	e.preventDefault();
	sendMsgChat();
	fieldTextChat.focus();
});//fim tela conversa .




});