<?php 

$nome = $_POST['nome'];
$msg  = $_POST['mensagem'];

print 'Olá '.$nome.'! , está e a resposta para sua pergunta: <strong>'.$msg.'</strong>. <br> Não consegui entender o que quis dizer, pode refazer a pergunta?';


 ?>